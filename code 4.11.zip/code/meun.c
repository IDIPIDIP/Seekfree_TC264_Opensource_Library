#include "zf_common_typedef.h"
#include "zf_common_headfile.h"

void menu(void)
{
    tft180_show_string(1,1,"mode1 key1");
    tft180_show_string(9,1,"mode2 key2");
    tft180_show_string(17,1,"mode3 key3");
    tft180_show_string(25,1,"mode4 point");
    if(key_get_state(KEY_1) == KEY_SHORT_PRESS)
    {
        key_clear_state(KEY_1);
        
    }
    if(key_get_state(KEY_2) == KEY_SHORT_PRESS)
    {
        key_clear_state(KEY_2);
        
    }
    if(key_get_state(KEY_3) == KEY_SHORT_PRESS)
    {
        key_clear_state(KEY_3);
    
    }
    if(key_get_state(KEY_4) == KEY_SHORT_PRESS)
    {
        key_clear_state(KEY_4);
        
    }
}
